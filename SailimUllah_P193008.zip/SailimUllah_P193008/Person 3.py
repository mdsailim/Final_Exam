#Question_3

class Person:
    people=[]
    def __init__(self,name,age):
        self.name=name
        self.age=age
    def __repr__(self):
        print(f"Name:{self.name},Age:{self.age}")
        return""

if __name__=="__main__":
    print("Enter person details.Type done to stop.")
    while True:
        name=input("Enter name:")
        if name.lower()=="done":
            break
        try:
            age=int(input("Enter age:"))
            Person(name,age)
        except ValueError:
            print("Invalid input for age.Please enter a number:")

        print("\nlist of people added:")
        for person in Person.people:
                  print (person)
