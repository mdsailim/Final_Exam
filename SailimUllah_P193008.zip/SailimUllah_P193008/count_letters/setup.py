from setuptools import setup

setup(
    name='GK_Quiz',
    version='1.1.0',
    description='Multiple-choice quiz with 10 questions',
    author='Sailim Ullah',
    author_email='sailim08@gmail.com',
    url='http://salimcods.com', 
    py_modules=['GK_Quiz'],
)
