from count_letters import count_letters

if __name__ == "__main__":
    text = "hello world"
    letters = "lo"
    result = count_letters(text, letters)
    print(result)  # Output: {'l': 3, 'o': 2}
