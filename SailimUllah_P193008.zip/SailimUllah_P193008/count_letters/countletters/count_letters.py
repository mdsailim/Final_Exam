def count_letters(text, letters):
    """
    Count occurrences of specific letters in a given text.

    Args:
        text (str): The text to analyze.
        letters (str): A string containing one or more letters to count.

    Returns:
        dict: A dictionary with letters as keys and their counts as values.
    """
    if not isinstance(text, str) or not isinstance(letters, str):
        raise ValueError("Both arguments must be strings.")

    letter_counts = {}
    for letter in letters:
        if letter in text:
            letter_counts[letter] = text.count(letter)

    return letter_counts
